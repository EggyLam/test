# Google Snake Custom Menu Stuff

## Enable the Mod
Paste the code from `custom.js` into the console, then type in the console:
```
window.snake.more_menu();
```
Or simply click the bookmark.

## Contributors
* [Fishes](https://github.com/fizhes)
* [ScienceCrafter](https://github.com/ScienceCrafter)
